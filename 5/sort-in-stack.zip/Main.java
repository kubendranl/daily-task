import java.util.*;
class Node{
    int data;
    Node next;
    Node(int val){
        data=val;
        next=null;
    }
}
class stack{
    Node top;
    void push(int val){
        Node newnode=new Node(val);
        newnode.next=top;
        top=newnode;
        
    }
    void sort(){
        if(top==null || top.next==null) return ;
        for(Node i=top;i!=null;i=i.next){
            for(Node j=i.next;j!=null;j=j.next){
                if(i.data>j.data){
                    int temp=i.data;
                    i.data=j.data;
                    j.data=temp;
                }
            }
        }
    }
    void display(){
    Node temp=top;
        while(temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;
        }
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         stack s = new stack();

        int n = sc.nextInt(); 

        for (int i = 0; i < n; i++) {
            int val = sc.nextInt();
            s.push(val);
        }
        s.sort();
        s.display();
        
    }
}







