import java.util.*;

class Node{
int data;
Node next;

Node(int val){
    data = val;
    next = null;
}


}

class LinkedListDemo{
Node head;


void insert(int val){
    Node newNode = new Node(val);

    if(head == null){
        head = newNode;
        return;
    }

    Node temp = head;
    while(temp.next != null){
        temp = temp.next;
    }
    temp.next = newNode;
}

void reverse(){
    Node prev = null;
    Node curr = head;
    Node next = null;

    while(curr != null){
        next = curr.next;
        curr.next = prev;
        prev = curr;
        curr = next;
    }
    head = prev;
}

void printTwoRows(int n){
    Node temp = head;

    for(int i=0;i<n/2;i++){
        System.out.print(temp.data + " ");
        temp = temp.next;
    }

    System.out.println();

    for(int i=n/2;i<n;i++){
        System.out.print(temp.data + " ");
        temp = temp.next;
    }
}
}
public class Main{
public static void main(String args[]){
    Scanner sc = new Scanner(System.in);

    int n = sc.nextInt();
    LinkedListDemo list = new LinkedListDemo();

    for(int i=0;i<n;i++){
        list.insert(sc.nextInt());
    }

    list.reverse();
    list.printTwoRows(n);
}
}
