import java.util.*;
class node{
    int data;
    node next;
    node (int val){
        data=val;
        next=null;
    }
}
class linked{
    node head;
    // void insert(int val){
    //     node newnode = new node(val);
    //   newnode.next=head;
    //   head=newnode;
    // }
    
    
    
    
    void insert(int val){
        node newnode = new node(val);
        if(head==null){
            head=newnode;
            return;
        }
        node temp=head;
        while(temp.next!=null){
            temp=temp.next;
        }
        temp.next=newnode;
    }
    
    void rig(){
      node 
        
    }
       
   
    void display(){
        
        if(head==null){
         System.out.print("empty");
            return;
        }
        node temp=head;
        while(temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;
        }
    }
}
public class Main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        linked l=new linked();
        
        int n=sc.nextInt();
        for(int i=0;i<n;i++){
            int val=sc.nextInt();
            l.insert(val);
        }
        l.find();
       
    }
}









