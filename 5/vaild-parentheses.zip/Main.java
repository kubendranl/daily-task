import java.util.*;
class Node {
	char data;
	Node next;
	Node (char val) {
		data=val;
		next=null;
	}
}
class Stack {
	Node top;
	void push(char val) {
		Node newNode=new Node(val);
		newNode.next=top;
		top=newNode;
	}
	char pop() {
		if(top==null) {
			return'0';
		}
		char poped=top.data;
		top=top.next;
		return poped;
	}
	boolean ismatch(char open,char close) {
		if(open=='('&& close==')') return true;
		if(open=='{'&& close=='}') return true;
		if(open=='['&& close==']') return true;
		return false;
	}
	boolean isbalanced(String exp) {
		for(int i=0; i<exp.length(); i++) {
			char ch= exp.charAt(i);
			if(ch=='('||ch=='{'||ch=='[')
				push (ch);
			else if(ch==')'||ch=='}'||ch==']') {
				if(top==null)
					return false;
				char poped=pop();
				if(!ismatch(poped,ch))
					return false;
		}
	        else {
				return false;
			}
		}
		return top==null;
	}
}                           
public class Main {
	public static void main(String[]args) {
		Stack s= new Stack();
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		if(s.isbalanced(str))
			System.out.print("balanced");
		else
			System.out.print("not blanced");
	}
}


