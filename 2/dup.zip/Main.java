import java.util.*;
class Node {
	int data;
	Node next;
	Node (int val) {
		data=val;
		next=null;
	}
}
class Linked {
	Node head;
	void insert(int val) {
		Node newNode=new Node(val);
		if(head==null) {
			head=newNode;
			return;
		}
		Node temp=head;
		while(temp.next!=null) {
			temp=temp.next;
		}
		temp.next=newNode;
	}



	void dup() {
		Node temp=head;
		while(temp!=null&& temp.next!=null) {
			if(temp.data==temp.next.data) {
				temp.next=temp.next.next;
			} else {
				temp=temp.next;
			}
		}
	}
	void display() {
		if(head==null) {
			System.out.print("Empty");
			return;
		}
		Node temp=head;
		while(temp!=null) {
			System.out.print(temp.data + " ");
			temp=temp.next;
		}
		System.out.println();
	}
}
public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	//	int t=sc.nextInt();
		//while(t--> 0) {
			Linked l=new Linked();
			int n=sc.nextInt();
			for(int i=0; i<n; i++) {
				int val=sc.nextInt();
				l.insert(val);

			}
			l.dup();
			l.display();
	//	}
	}
}

