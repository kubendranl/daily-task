import java.util.Scanner;

class Node {
    int data;
    Node next;
    Node prev;

    Node(int d) {
        data = d;
        next = null;
        prev = null;
    }
}

class Deque {
    Node front = null;
    Node rear = null;

    void insertFront(int value) {
        Node newNode = new Node(value);

        if (front == null) {
            front = rear = newNode;
        } else {
            newNode.next = front;
            front.prev = newNode;
            front = newNode;
        }
        System.out.println("Inserted at front");
    }

    void insertRear(int value) {
        Node newNode = new Node(value);

        if (rear == null) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            newNode.prev = rear;
            rear = newNode;
        }
        System.out.println("Inserted at rear");
    }

    void deleteFront() {
        if (front == null) {
            System.out.println("Deque is empty");
            return;
        }

        System.out.println("Deleted: " + front.data);

        if (front == rear) {
            front = rear = null;
        } else {
            front = front.next;
            front.prev = null;
        }
    }

    void deleteRear() {
        if (rear == null) {
            System.out.println("Deque is empty");
            return;
        }

        System.out.println("Deleted: " + rear.data);

        if (front == rear) {
            front = rear = null;
        } else {
            rear = rear.prev;
            rear.next = null;
        }
    }

    void display() {
        if (front == null) {
            System.out.println("Deque is empty");
            return;
        }

        Node temp = front;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Deque dq = new Deque();
        int choice, value;

        do {
         
            choice = sc.nextInt();

            if (choice == 1) {
               
                value = sc.nextInt();
                dq.insertFront(value);
            } 
            else if (choice == 2) {
              
                value = sc.nextInt();
                dq.insertRear(value);
            } 
            else if (choice == 3) {
                dq.deleteFront();
            } 
            else if (choice == 4) {
                dq.deleteRear();
            } 
            else if (choice == 5) {
                dq.display();
            }

        } while (choice != 6);

        System.out.println("Program Ended");
    }
}