import java.util.*;

class Node {
    char data;
    Node next;

    Node(char val) {
        data = val;
        next = null;
    }
}

class Stack {
    Node top;

    void push(char val) {
        Node newNode = new Node(val);
        newNode.next = top;
        top = newNode;
    }

    char pop() {
        if (top == null)
            return '\0';
        char val = top.data;
        top = top.next;
        return val;
    }

    char peek() {
        if (top == null)
            return '\0';
        return top.data;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String exp = sc.next();

        Stack st = new Stack();
        boolean duplicate = false;

        for (int i = 0; i < exp.length(); i++) {

            char ch = exp.charAt(i);

            if (ch == ')') {
                char top = st.pop();
                int count = 0;

                while (top != '(') {
                    count++;
                    top = st.pop();
                }

                if (count == 0) {
                    duplicate = true;
                    break;
                }
            } else {
                st.push(ch);
            }
        }

        if (duplicate)
            System.out.println("Yes");
        else
            System.out.println("No");
    }
}