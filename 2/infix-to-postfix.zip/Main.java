import java.util.*;

class Node {
	char data;
	Node next;

	Node(char val) {
		data = val;
		next = null;
	}
}
class Stack{
	Node top;
	void push(char val) {
		Node newNode = new Node(val);
		newNode.next = top;
		top = newNode;
	}
	char pop() {
		if (top == null)
			return '0';
		char popped = top.data;
		top = top.next;
		return popped;
	}
	char peek() {
		if (top == null)
			return '0';

		return top.data;
	}
	boolean isEmpty() {
		return top == null;
	}
}
public class Main {
	static int precedence(char ch) {
		if (ch == '+' || ch == '-') return 1;
		if (ch == '*' || ch == '/') return 2;
		if (ch == '^') return 3;
		return -1;
	}
	static String infixToPostfix(String exp) {
		Stack s = new Stack();
		String res = "";
		for (int i = 0; i < exp.length(); i++) {
			char ch = exp.charAt(i);
			if ((ch >= 'A' && ch <= 'Z') ||
			        (ch >= 'a' && ch <= 'z') ||
			        (ch >= '0' && ch <= '9')) {
				res += ch;
			}
			else if (ch == '(') {
				s.push(ch);
			}
			else if (ch == ')') {
				while (!s.isEmpty() && s.peek() != '(') {
					res += s.pop();
				}
				s.pop();
			}
			else {
				while (!s.isEmpty() &&
				        precedence(s.peek()) >= precedence(ch)) {
					res += s.pop();
				}
				s.push(ch);
			}
		}
		while (!s.isEmpty()) {
			res += s.pop();
		}
		return res;
	}
public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String exp = sc.nextLine();
		System.out.println(infixToPostfix(exp));
		
	}
}



