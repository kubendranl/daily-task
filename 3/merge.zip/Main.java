import java.util.*;
class Node {
	int data;
	Node next;
	Node (int val) {
		data=val;
		next=null;
	}
}
class Linked {
	Node head;
	void insert(int val) {
		Node newNode=new Node(val);
		if(head==null) {
			head=newNode;
			return;
		}
		Node temp=head;
		while(temp.next!=null) {
			temp=temp.next;
		}
		temp.next=newNode;
	}
	void display() {
		if(head==null) {
			System.out.print("Empty");
			return;
		}
		Node temp=head;
		while(temp!=null) {
			System.out.print(temp.data + " ");
			temp=temp.next;
		}
	}
	static Node merge (Node h1, Node h2){
	    
	    if(h1==null) return h2;
	    if(h2==null)return h1;
	     Node head;
	     if(h1.data<=h2.data){
	         head=h1;
	         h1=h1.next;
	     }else{
	         head=h2;
	         h2=h2.next;
	     }
	     Node curr=head;
	     while(h1!=null && h2!=null){
	         if(h1.data<=h2.data){
	             curr.next=h1;
	             h1=h1.next;
	         }else{
	             curr.next=h2;
	             h2=h2.next;
	         }
	         curr=curr.next;
	     }
	     if(h1!=null){
	         curr.next=h1;
	     }else{
	         curr.next=h2;
	     }
	     return head;
	}

}
public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	Linked l1=new Linked();
		Linked l2=new Linked();
		int n1=sc.nextInt();
		for(int i=0;i<n1;i++){
		    int val=sc.nextInt();
		    l1.insert(val);
		}
			int n2=sc.nextInt();
		for(int i=0;i<n2;i++){
		    int val=sc.nextInt();
		    l2.insert(val);
		}
	 Node mergehead=Linked.merge(l1.head,l2.head);
		Node temp=mergehead;
			while(temp!=null) {
			System.out.print(temp.data + " ");
			temp=temp.next;
		}
}
}
















