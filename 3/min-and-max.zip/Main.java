import java.util.*;
class Node{
    int data;
    Node next;
    Node(int val){
        data=val;
        next=null;
    }
}
class stack{
    Node top;
    void push(int val){
        Node newnode=new Node(val);
        newnode.next=top;
        top=newnode;
        
    }
    int pop(){
        if(top==null) return -1;
        int poped=top.data;
        top=top.next;
        return poped;
    }
    int findmin(){
        if(top==null) return -1;
        int min=top.data;
        Node temp=top;
        while(temp!=null){
            if(temp.data<min){
                min=temp.data;
            }
            temp=temp.next;
        }
        return min;
    }
    void display(){
    Node temp=top;
        while(temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;
        }
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         stack s = new stack();

        int n = sc.nextInt(); 

        for (int i = 0; i < n; i++) {
            int val = sc.nextInt();
            s.push(val);
        }
        s.display();
        System.out.println();
          int popped = s.pop();
            System.out.println(popped);
        s.display();
        System.out.println();

        System.out.println( s.findmin());
    }
}







