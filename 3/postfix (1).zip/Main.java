import java.util.*;
class Node{
    int data;
    Node next;
    Node(int val){
        data=val;
        next=null;
    }
}
class stack{
    Node top;
    void push(int val){
        Node newnode=new Node(val);
        newnode.next=top;
        top=newnode;
        
    }
   int pop(){
      if(top==null) return -1;
      int poped=top.data;
      top=top.next;
      return poped;
   }
   
}
public class Main {
    
    static int postfix(String exp){
        stack s = new stack();
        for (int i = 0; i < exp.length(); i++) {
            char ch=exp.charAt(i);
            if(Character.isDigit(ch)){
                s.push(ch-'0');
            }
            else {
                int op2 = s.pop();
                int op1 = s.pop();
                int result = 0;
                if (ch == '+')
                    result = op1 + op2;
                else if (ch == '-')
                    result = op1 - op2;
                else if (ch == '*')
                    result = op1 * op2;
                else if (ch == '/')
                    result = op1 / op2;

                s.push(result);
            }
        }

        return s.pop();
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String exp = sc.nextLine(); 
        System.out.println(postfix(exp));
    }
}