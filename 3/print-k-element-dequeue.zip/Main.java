import java.util.Scanner;

class Node {
    int data;
    Node next;

    Node(int d) {
        data = d;
        next = null;
    }
}

class Queue {
    Node front = null;
    Node rear = null;

    void enqueue(int value) {
        Node newNode = new Node(value);

        if (rear == null) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    int dequeue() {
        if (front == null) {
            return -1;
        }

        int value = front.data;
        front = front.next;

        if (front == null) {
            rear = null;
        }

        return value;
    }

    boolean isEmpty() {
        return front == null;
    }

    int size() {
        int count = 0;
        Node temp = front;
        while (temp != null) {
            count++;
            temp = temp.next;
        }
        return count;
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Queue q = new Queue();
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            q.enqueue(sc.nextInt());
        }
        int k = sc.nextInt();

        int size = q.size();

        if (k > size) {
            System.out.println("k is greater than queue size");
            return;
        }

        Queue temp = new Queue();

        for (int i = 0; i < size; i++) {
            int value = q.dequeue();

            if (i < k) {
                System.out.print(value + " ");
            }

            temp.enqueue(value);
        }
        for (int i = 0; i < size; i++) {
            q.enqueue(temp.dequeue());
        }
    }
}