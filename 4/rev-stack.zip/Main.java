import java.util.*;

class Node {
    char data;
    Node next;

    Node(char val) {
        data = val;
        next = null;
    }
}

class Stack {
    Node top;

    void push(char val) {
        Node newNode = new Node(val);
        newNode.next = top;
        top = newNode;
    }

    char pop() {
        if (top == null) {
            return '\0';
        }
        char temp = top.data;
        top = top.next;
        return temp;
    }
    boolean isEmpty() {
        return top == null;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String str = sc.nextLine();

        Stack s = new Stack();
 for (int i = 0; i < str.length(); i++) {
            s.push(str.charAt(i));
        }

        String reversed = "";
        while (!s.isEmpty()) {
            reversed += s.pop();
        }

        System.out.println(reversed);
    }
}