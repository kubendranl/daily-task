import java.util.*;
class Node {
	int data;
	Node next;
	Node(int val) {
		data=val;
		next=null;
	}
}
class Linked {
	Node head;
	void insert(int val) {
		Node newNode=new Node(val);
		if(head==null) {
			head=newNode;
			return;
		}
		Node temp=head;
		while(temp.next!=null) {
			temp=temp.next;
		}
		temp.next=newNode;
	}

	void display() {
		if(head==null) {
			System.out.print("Empty");
			return;
		}
		Node temp=head;
		while(temp!=null) {
			System.out.print(temp.data + " ");
			temp=temp.next;
		}
	}

}
public class Main {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		Linked  l=new Linked ();

		int n=sc.nextInt();

		for(int i=0; i<n; i++) {
			int val=sc.nextInt();
			l.insert(val);
		}
		l.display();
	}
}



