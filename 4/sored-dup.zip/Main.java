import java.util.*;
class Node {
	int data;
	Node next;
	Node (int val) {
		data=val;
		next=null;
	}
}
class Linked {
	Node head;
	void insert(int val) {
		Node newNode=new Node(val);
		newNode.next=head;
		head=newNode;
	}



	void dup() {
	    Node cur=head;
	    while(cur!=null){
		Node temp=cur;
		while(temp!=null&& temp.next!=null) {
			if(temp.next.data==cur.data) {
				temp.next=temp.next.next;
			} else {
				temp=temp.next;
			}
		}
		cur=cur.next;
	    }
	}
	void display() {
		if(head==null) {
			System.out.print("Empty");
			return;
		}
		Node temp=head;
		while(temp!=null) {
			System.out.print(temp.data + " ");
			temp=temp.next;
		}
		System.out.println();
	}
}
public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	
			Linked l=new Linked();
			int n=sc.nextInt();
			for(int i=0; i<n; i++) {
				int val=sc.nextInt();
				l.insert(val);

			}
			l.dup();
			l.display();

	}
}
//10
//12 12 10 4 8 4 6 4 4 8
// 8 4 6 10 12
